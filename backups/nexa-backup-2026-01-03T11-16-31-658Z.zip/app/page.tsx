'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Volume2, VolumeX, Plus, MessageSquare, AlertCircle, Settings, Globe, HelpCircle, ArrowUp, Gift, Download, LogOut, User, FolderPlus, Code, X, Search, Sparkles, Zap, Image, Video, Book, Briefcase, Calendar, PenTool, Lightbulb, FileText, Layout, Paperclip, Music, ChevronDown, ChevronUp, PanelLeft, Eye, EyeOff, Check, Copy, Clock, Loader2, Play, CheckCircle2, HardDrive, Shield, RotateCcw, Menu, Palette, Compass, Newspaper, GraduationCap, MoreHorizontal, Headphones } from 'lucide-react';
import JSZip from 'jszip';
import { AuthModal } from '../components/AuthModal';
import { auth, db } from '../lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';

// CodeBlock Component
const CodeBlock = ({ language, code }: { language: string, code: string }) => {
  const [showPreview, setShowPreview] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Determine if code is previewable (HTML or SVG)
  const isPreviewable = ['html', 'svg', 'xml'].includes(language.toLowerCase()) || 
                       (language === '' && code.trim().startsWith('<'));

  return (
    <div className="my-4 rounded-lg overflow-hidden border border-gray-200 bg-white shadow-sm">
      <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b border-gray-200">
        <span className="text-xs font-semibold text-gray-500 uppercase">{language || 'code'}</span>
        <div className="flex items-center gap-2">
           {isPreviewable && (
             <button 
               onClick={() => setShowPreview(!showPreview)} 
               className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-gray-500 hover:text-blue-600 hover:bg-white rounded-md transition-all"
             >
               {showPreview ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
               {showPreview ? 'Ocultar' : 'Preview'}
             </button>
           )}
           <button 
             onClick={handleCopy} 
             className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-gray-500 hover:text-green-600 hover:bg-white rounded-md transition-all"
           >
             {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
             {copied ? 'Copiado' : 'Copiar'}
          </button>
       </div>
    </div>
    
    {showPreview ? (
        <div className="p-0 bg-white border-b border-gray-200 relative group">
           <iframe 
             srcDoc={code} 
             className="w-full h-[400px] border-0 bg-white" 
             sandbox="allow-scripts"
             title="Preview"
           />
        </div>
      ) : (
        <div className="relative group">
            <pre className="p-4 overflow-x-auto text-sm font-mono text-gray-800 bg-gray-50 whitespace-pre">
            {code}
            </pre>
        </div>
      )}
    </div>
  )
}

declare global {
  interface Window {
    storage?: any;
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

export default function ChatApp() {
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userName, setUserName] = useState('Invitado');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        setUserName(currentUser.displayName || currentUser.email?.split('@')[0] || 'Usuario');
        
        // Save user to Firestore if not exists
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (!userDoc.exists()) {
            await setDoc(userDocRef, {
              uid: currentUser.uid,
              email: currentUser.email,
              displayName: currentUser.displayName,
              photoURL: currentUser.photoURL,
              createdAt: new Date().toISOString(),
              role: 'user'
            });
          }
        } catch (error) {
          console.error("Error creating user document:", error);
        }
      } else {
        setUserName('Invitado');
      }
    });

    return () => unsubscribe();
  }, []);
  const [menuExpanded, setMenuExpanded] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [language, setLanguage] = useState<'es' | 'en' | 'zh'>('es');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [mode, setMode] = useState<'fast'|'deep'>('fast');
  const [codeMode, setCodeMode] = useState(false);
  const [autoVoiceMode, setAutoVoiceMode] = useState(false);
  const [showCreative, setShowCreative] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const [fileTexts, setFileTexts] = useState<Array<{ name: string; text: string }>>([]);
  const [isOnline, setIsOnline] = useState(true);
  const [conversations, setConversations] = useState<Array<{id: string, title: string, date: string, messages: any[]}>>([]);
  const [showConversations, setShowConversations] = useState(false);
  const [showUploadMenu, setShowUploadMenu] = useState(false);
  const [showAllApps, setShowAllApps] = useState(false);
  // Video Gen States
  const [showVideoGen, setShowVideoGen] = useState(false);
  const [videoGenFile, setVideoGenFile] = useState<File | null>(null);
  const [videoPrompt, setVideoPrompt] = useState('');
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [generatedVideo, setGeneratedVideo] = useState<boolean>(false);
  const [isBackingUp, setIsBackingUp] = useState(false);

  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const audioInputRef = useRef<HTMLInputElement | null>(null);
  const docInputRef = useRef<HTMLInputElement | null>(null);

  const handleGenerateVideo = () => {
    setIsGeneratingVideo(true);
    // Simulation of video generation process
    setTimeout(() => {
        setIsGeneratingVideo(false);
        setGeneratedVideo(true);
    }, 3000);
  };

  useEffect(() => {
    setIsOnline(navigator.onLine);
    const handleStatus = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleStatus);
    window.addEventListener('offline', handleStatus);
    return () => {
      window.removeEventListener('online', handleStatus);
      window.removeEventListener('offline', handleStatus);
    };
  }, []);

  useEffect(() => {
    const initPdf = async () => {
      if (typeof window === 'undefined') return;
      try {
        const pdfjsLibModule = await import('pdfjs-dist/build/pdf');
        const pdfjsLib = pdfjsLibModule.default || pdfjsLibModule;
        const workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;
        
        if (pdfjsLib.GlobalWorkerOptions) {
            pdfjsLib.GlobalWorkerOptions.workerSrc = workerSrc;
        }
      } catch (e) {
        console.error("PDF init error", e);
      }
    };
    initPdf();

    // Load offline history
    const savedHistory = localStorage.getItem('nexa_conversations');
    if (savedHistory) {
        try {
            setConversations(JSON.parse(savedHistory));
        } catch (e) { console.error(e); }
    }

    const savedMessages = localStorage.getItem('nexa_chat_history');
    if (savedMessages) {
        try {
            setMessages(JSON.parse(savedMessages));
        } catch (e) {
            console.error("Error loading history", e);
        }
    }
  }, []);

  useEffect(() => {
      localStorage.setItem('nexa_chat_history', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
      localStorage.setItem('nexa_conversations', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
      localStorage.setItem('nexa_settings_language', language);
  }, [language]);

  useEffect(() => {
      localStorage.setItem('nexa_settings_voice', JSON.stringify(voiceEnabled));
  }, [voiceEnabled]);

  useEffect(() => {
      const savedLang = localStorage.getItem('nexa_settings_language');
      if (savedLang && (savedLang === 'es' || savedLang === 'en' || savedLang === 'zh')) {
          setLanguage(savedLang);
      }
      const savedVoice = localStorage.getItem('nexa_settings_voice');
      if (savedVoice) {
          setVoiceEnabled(JSON.parse(savedVoice));
      }

      // Auto-repair check
      const checkAutoRepair = async () => {
        const localConv = localStorage.getItem('nexa_conversations');
        const localMsg = localStorage.getItem('nexa_chat_history');
        
        if ((!localConv || localConv === '[]') && (!localMsg || localMsg === '[]')) {
             try {
                const res = await fetch('/api/system/restore');
                const data = await res.json();
                if (data.success && data.data) {
                    // Simulating "Auto Repair" by asking user
                    if (confirm('⚠️ NEXA OS: Se detectó una posible pérdida de datos. ¿Deseas ejecutar la AUTO-REPARACIÓN desde la última copia de seguridad?')) {
                        const { messages: msgs, conversations: convs, settings } = data.data;
                        if(msgs) setMessages(msgs);
                        if(convs) setConversations(convs);
                        if(settings) {
                            if(settings.language) setLanguage(settings.language);
                            if(settings.userName) setUserName(settings.userName);
                            if(settings.voiceEnabled !== undefined) setVoiceEnabled(settings.voiceEnabled);
                        }
                    }
                }
             } catch(e) { console.error("Auto-repair check failed", e); }
        }
     };
     setTimeout(checkAutoRepair, 1500);
  }, []);

  const startNewChat = () => {
      if (messages.length > 0) {
          const newChat = {
              id: Date.now().toString(),
              title: messages[0].content.substring(0, 30) + '...',
              date: new Date().toLocaleDateString(),
              messages: [...messages]
          };
          setConversations(prev => [newChat, ...prev]);
      }
      setMessages([]);
      setInput('');
      setError(null);
      stopSpeaking();
      setShowConversations(false);
  };

  const loadConversation = (id: string) => {
      const chat = conversations.find(c => c.id === id);
      if (chat) {
          if (messages.length > 0) {
             // Save current before switching? Maybe optional.
          }
          setMessages(chat.messages);
          setShowConversations(false);
      }
  };

  const deleteConversation = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setConversations(prev => prev.filter(c => c.id !== id));
  };

  const handleSystemBackup = async () => {
    setIsBackingUp(true);
    try {
      const userData = {
         messages,
         conversations,
         settings: { language, voiceEnabled, userName }
      };
      
      const res = await fetch('/api/system/backup', {
         method: 'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify({ userData })
      });
      
      if (res.ok) {
         alert('Copia de seguridad completada exitosamente en la carpeta /backups');
      } else {
         throw new Error('Error en el backup');
      }
    } catch (e) {
      console.error(e);
      alert('Error al realizar la copia de seguridad');
    } finally {
      setIsBackingUp(false);
    }
  };
  
  const handleSystemRestore = async () => {
     if(!confirm('¿Estás seguro? Esto sobrescribirá tus datos actuales con la última copia de seguridad.')) return;
     
     try {
       const res = await fetch('/api/system/restore');
       const data = await res.json();
       
       if (data.success && data.data) {
          const { messages: msgs, conversations: convs, settings } = data.data;
          if(msgs) setMessages(msgs);
          if(convs) setConversations(convs);
          if(settings) {
              if(settings.language) setLanguage(settings.language);
              if(settings.userName) setUserName(settings.userName);
              if(settings.voiceEnabled !== undefined) setVoiceEnabled(settings.voiceEnabled);
          }
          alert('Sistema restaurado correctamente.');
          setShowSettings(false);
       } else {
          alert('No se encontró ninguna copia de seguridad válida.');
       }
     } catch (e) {
       console.error(e);
       alert('Error al restaurar el sistema');
     }
  };

  const processFile = async (file: File): Promise<{name: string, text: string} | null> => {
    try {
      if (file.type === 'application/pdf') {
        // Use require to avoid ESM issues
        const pdfjsLibModule = await import('pdfjs-dist');
        const pdfjsLib = pdfjsLibModule.default || pdfjsLibModule;
        
        const data = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data }).promise;
        const parts: string[] = [];
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const content = await page.getTextContent();
          // @ts-ignore
          parts.push(content.items.map((it: any) => it.str).join(' '));
        }
        return { name: file.name, text: parts.join('\n\n') };
      } else if (
        file.type.startsWith('text/') || 
        file.name.endsWith('.md') || 
        file.name.endsWith('.json') || 
        file.name.endsWith('.ts') || 
        file.name.endsWith('.tsx') || 
        file.name.endsWith('.js') || 
        file.name.endsWith('.csv') ||
        file.name.endsWith('.txt')
      ) {
         const text = await file.text();
         return { name: file.name, text };
      }
      return null;
    } catch (e) {
      console.error("Error processing file:", e);
      return null;
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const loadUserName = async () => {
      try {
        if (window.storage?.get) {
          const result = await window.storage.get('nexa_user_name');
          if (result?.value) {
            setUserName(result.value);
          }
        }
      } catch (err) {
        console.log('Usuario nuevo:', err);
      }
    };
    loadUserName();
  }, []);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [input]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      const langMap: Record<'es'|'en'|'zh', string> = { es: 'es-ES', en: 'en-US', zh: 'zh-CN' };
      recognitionRef.current.lang = langMap[language];

      recognitionRef.current.onstart = () => {
        setIsListening(true);
        setError(null);
      };

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        if (autoVoiceMode && event.results[0].isFinal) {
            // Give a small delay to ensure state is updated
            setTimeout(() => {
                document.getElementById('send-button')?.click();
            }, 500);
        }
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Error de reconocimiento:', event.error);
        setIsListening(false);
        
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        
        switch(event.error) {
          case 'no-speech':
            setError('No se detectó voz. Intenta de nuevo.');
            break;
          case 'not-allowed':
            setError(isIOS ? 
              'Permite el acceso al micrófono en Configuración > Safari > Micrófono.' : 
              'Permite el acceso al micrófono en la configuración del navegador.');
            break;
          case 'network':
            setError('Error de red. Verifica tu conexión.');
            break;
          default:
            setError('Error de reconocimiento de voz.');
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [autoVoiceMode]);

  const checkMicrophonePermission = async () => {
    try {
      const result = await navigator.permissions.query({ name: 'microphone' });
      return result.state;
    } catch (err) {
      return 'prompt';
    }
  };

  const toggleVoiceRecognition = async () => {
    if (!recognitionRef.current) {
      setError('Reconocimiento de voz no disponible en este navegador.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      return;
    }

    try {
      const permissionState = await checkMicrophonePermission();
      
      if (permissionState === 'denied') {
        setError('❌ Micrófono bloqueado. Haz clic en el ícono 🔒 o ⓘ en la barra de direcciones y permite el micrófono.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      
      setError(null);
      recognitionRef.current.start();
    } catch (err: any) {
      console.error('Error de micrófono:', err);
      
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('❌ Permiso denegado. Haz clic en el ícono 🔒 junto a la URL y permite el micrófono, luego recarga la página.');
      } else if (err.name === 'NotFoundError') {
        setError('❌ No se encontró ningún micrófono conectado.' as string);
      } else if (err.name === 'NotReadableError') {
        setError('❌ El micrófono está siendo usado por otra aplicación.');
      } else {
        setError('❌ Error al acceder al micrófono. Verifica los permisos del navegador.');
      }
    }
  };

  const speakText = (text: string) => {
    if (!voiceEnabled || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    
    setTimeout(() => {
      const utterance = new SpeechSynthesisUtterance(text);
      
      const voices = window.speechSynthesis.getVoices();
      const voice = voices.find(v => {
        if (language === 'es') return v.lang.toLowerCase().startsWith('es');
        if (language === 'en') return v.lang.toLowerCase().startsWith('en');
        return v.lang.toLowerCase().startsWith('zh');
      });
      if (voice) utterance.voice = voice;
      const langMap: Record<'es'|'en'|'zh', string> = { es: 'es-ES', en: 'en-US', zh: 'zh-CN' };
      utterance.lang = langMap[language];
      utterance.rate = 1;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onstart = () => {
        setIsSpeaking(true);
      };
      
      utterance.onend = () => {
        setIsSpeaking(false);
        if (autoVoiceMode) {
            setTimeout(() => toggleVoiceRecognition(), 500);
        }
      };
      
      utterance.onerror = (event: any) => {
        console.error('Error en síntesis de voz:', event);
        setIsSpeaking(false);
      };

      window.speechSynthesis.speak(utterance);
    }, 100);
  };

  const stopSpeaking = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const stopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
      stopSpeaking();
      setMessages(prev => [...prev, {
        role: 'system',
        content: '⏹️ Generación cancelada'
      }]);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    // INTERCEPTION: Detect video generation intent
    const lowerInput = input.toLowerCase();
    const isVideoRequest = lowerInput.includes('video') && (lowerInput.includes('generar') || lowerInput.includes('crear') || lowerInput.includes('haz') || lowerInput.includes('make') || lowerInput.includes('create'));
    
    if (isVideoRequest) {
      const userMessage = { role: 'user', content: input.trim() };
      setMessages(prev => [...prev, userMessage]);
      setInput('');
      setIsLoading(true);
      
      // Simulate processing time
      setTimeout(() => {
        setIsLoading(false);
        setMessages(prev => [...prev, {
            role: 'assistant',
            content: "¡Claro que sí! Puedo ayudarte a generar ese video. He abierto la herramienta **Video Gen** para ti. Por favor, ingresa los detalles en el panel que acaba de aparecer."
        }]);
        setShowVideoGen(true);
        if (voiceEnabled) speakText("¡Claro que sí! Puedo ayudarte a generar ese video. He abierto la herramienta Video Gen para ti.");
      }, 1000);
      return;
    }

    const attachmentNote = attachments.length ? `\nAdjuntos: ${attachments.map(f => f.name).join(', ')}` : '';
    const fileNote = fileTexts.length ? `\n\n${fileTexts.map(p => `[FILE ${p.name}]\n${p.text}`).join('\n\n')}` : '';
    const userMessage = { role: 'user', content: input.trim() + attachmentNote + fileNote };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setAttachments([]);
    setFileTexts([]);
    setIsLoading(true);
    setError(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    abortControllerRef.current = new AbortController();

    try {
      const conversationHistory = messages
        .filter(m => m.role !== 'system')
        .map(msg => ({
          role: msg.role === 'user' ? 'user' : 'assistant',
          content: msg.content
        }));

      // Convert image attachments to base64 for vision analysis
      const imageFiles = attachments.filter(f => f.type.startsWith('image/'));
      const readAsBase64 = (file: File) => new Promise<{ media_type: string; data: string }>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          const base64 = result.split(',')[1];
          resolve({ media_type: file.type, data: base64 });
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const imageAttachments = await Promise.all(imageFiles.map(readAsBase64)).catch(() => []);

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [...conversationHistory, {
            role: 'user',
            content: userMessage.content
          }],
          language,
          attachments: imageAttachments,
          mode,
          codeMode,
          provider: 'anthropic' // Send selected provider
        }),
        signal: abortControllerRef.current.signal
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error?.message || `Error del servidor: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.content?.[0]?.text) {
        throw new Error('Respuesta inválida del servidor');
      }

      const assistantMessage = {
        role: 'assistant',
        content: data.content[0].text
      };

      setMessages(prev => [...prev, assistantMessage]);

      if (voiceEnabled) {
        speakText(data.content[0].text);
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        return;
      }
      
      console.error('Error:', error);
      setError(error.message || 'Error al procesar tu mensaje');
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Lo siento, hubo un error al procesar tu mensaje. Por favor, intenta de nuevo.'
      }]);
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
      if (textareaRef.current) {
        textareaRef.current.blur();
      }
    }
  };

  const saveUserName = async (name: string) => {
    try {
      if (window.storage?.set) {
        await window.storage.set('nexa_user_name', name);
      }
    } catch (err) {
      console.error('Error al guardar nombre:', err);
    }
  };

  const handleNameChange = () => {
    const newName = prompt('¿Cómo te llamas?', userName);
    if (newName && newName.trim()) {
      const trimmedName = newName.trim();
      setUserName(trimmedName);
      saveUserName(trimmedName);
    }
  };

  const handleLogout = async () => {
    setUserName('Invitado');
    try {
      if (window.storage?.delete) {
        await window.storage.delete('nexa_user_name');
      }
    } catch (err) {
      console.error('Error:', err);
    }
    setMessages([]);
    setMenuExpanded(false);
  };

  const quickActions = [
    { id: 'image_edit', label: 'Editar Imagen', icon: <Palette className="w-3.5 h-3.5" />, color: 'text-purple-600 bg-purple-50 border-purple-200' },
    { id: 'web_dev', label: 'Desarrollo Web', icon: <Globe className="w-3.5 h-3.5" />, color: 'text-blue-600 bg-blue-50 border-blue-200' },
    { id: 'learn', label: 'Aprender', icon: <GraduationCap className="w-3.5 h-3.5" />, color: 'text-green-600 bg-green-50 border-green-200' },
    { id: 'research', label: 'Investigación', icon: <Search className="w-3.5 h-3.5" />, color: 'text-amber-600 bg-amber-50 border-amber-200' },
    { id: 'image_gen', label: 'Generar Imagen', icon: <Image className="w-3.5 h-3.5" />, color: 'text-pink-600 bg-pink-50 border-pink-200' },
    { id: 'video_gen', label: 'Generar Video', icon: <Video className="w-3.5 h-3.5" />, color: 'text-red-600 bg-red-50 border-red-200' },
    { id: 'code', label: 'Código', icon: <Code className="w-3.5 h-3.5" />, color: 'text-slate-600 bg-slate-50 border-slate-200' },
    { id: 'plan', label: 'Planificar', icon: <Calendar className="w-3.5 h-3.5" />, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' },
    { id: 'news', label: 'Noticias', icon: <Newspaper className="w-3.5 h-3.5" />, color: 'text-orange-600 bg-orange-50 border-orange-200' },
    { id: 'analyze', label: 'Analizar', icon: <Eye className="w-3.5 h-3.5" />, color: 'text-cyan-600 bg-cyan-50 border-cyan-200' },
    { id: 'summary', label: 'Resumir', icon: <FileText className="w-3.5 h-3.5" />, color: 'text-teal-600 bg-teal-50 border-teal-200' },
    { id: 'write', label: 'Redactar', icon: <PenTool className="w-3.5 h-3.5" />, color: 'text-rose-600 bg-rose-50 border-rose-200' },
    { id: 'idea', label: 'Ideas', icon: <Zap className="w-3.5 h-3.5" />, color: 'text-yellow-600 bg-yellow-50 border-yellow-200' },
    { id: 'travel', label: 'Viajes', icon: <Compass className="w-3.5 h-3.5" />, color: 'text-sky-600 bg-sky-50 border-sky-200' },
  ];

  const handleQuickAction = (actionId: string) => {
    // Manejo de acciones rápidas
    if (actionId === 'video_gen') {
        setShowVideoGen(true);
        if (voiceEnabled) speakText("Abriendo el generador de video.");
        return;
    }
    
    const prompts: Record<string, string> = {
        'image_edit': "Edita esta imagen para...",
        'web_dev': "Crea una página web que...",
        'learn': "Explícame el concepto de...",
        'research': "Investiga sobre...",
        'image_gen': "Genera una imagen de...",
        'code': "Escribe un código en Python para...",
        'plan': "Crea un plan para...",
        'news': "Búscame las últimas noticias sobre...",
        'analyze': "Analiza esta imagen y dime...",
        'summary': "Resume el siguiente texto:",
        'write': "Ayúdame a redactar un...",
        'idea': "Dame ideas para...",
        'travel': "Planifica un viaje a..."
    };

    if (prompts[actionId]) {
        setInput(prompts[actionId]);
        if (textareaRef.current) textareaRef.current.focus();
    }
  };

  return (
    <div className="flex h-screen bg-white overflow-hidden font-sans text-gray-900">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div 
        className={`${
          sidebarOpen ? 'translate-x-0 w-64' : '-translate-x-full w-64 md:translate-x-0 md:w-[72px]'
        } transition-all duration-300 ease-in-out bg-white border-r border-gray-200 flex flex-col fixed inset-y-0 left-0 z-40 md:relative md:z-20 h-full shadow-2xl md:shadow-none`}
      >
        {/* Header Section */}
        <div className="flex flex-col pt-6 pb-4 px-4 gap-4">
            <div className="flex items-center justify-between">
                {sidebarOpen && (
                    <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 bg-clip-text text-transparent animate-pulse tracking-tight ml-2 drop-shadow-sm">
                      Nexa OS
                    </h1>
                )}
                <button
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                  className={`p-2 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors ${!sidebarOpen ? 'mx-auto' : ''}`}
                >
                  <PanelLeft className="w-5 h-5" />
                </button>
            </div>
        </div>

        {/* Main Actions */}
        <div className="flex flex-col px-3 gap-2">
            <button 
                onClick={startNewChat}
                className={`flex items-center gap-2 p-2 rounded-lg transition-all text-gray-600 hover:bg-gray-100 hover:text-gray-900 ${!sidebarOpen ? 'justify-center' : ''}`}
                title="New Chat"
            >
                <Plus className="w-4 h-4 shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">New Chat</span>}
            </button>

            <button 
                onClick={() => setShowCreative(true)}
                className={`flex items-center gap-2 p-2 rounded-lg transition-all text-gray-600 hover:bg-gray-100 hover:text-gray-900 ${!sidebarOpen ? 'justify-center' : ''}`}
                title="New Project"
            >
                <FolderPlus className="w-4 h-4 shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">New Project</span>}
            </button>

            <button 
                onClick={() => {
                    setShowConversations(!showConversations);
                    if (!sidebarOpen) setSidebarOpen(true);
                }}
                className={`flex items-center gap-2 p-2 rounded-lg transition-all ${showConversations ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'} ${!sidebarOpen ? 'justify-center' : ''}`}
                title="All Chats"
            >
                <Search className="w-4 h-4 shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">All Chats</span>}
            </button>
        </div>

        {/* Conversations List (Only when open) */}
        {sidebarOpen && (
          <div className="flex-1 overflow-y-auto px-3 py-4 mt-2">
            {showConversations ? (
                <div className="space-y-2 animate-in fade-in slide-in-from-left-4 duration-300">
                    <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-2 mb-3">Historial</h3>
                    {conversations.length === 0 && <p className="text-xs text-gray-400 text-center py-4">No hay conversaciones</p>}
                    {conversations.map(chat => (
                        <div key={chat.id} onClick={() => loadConversation(chat.id)} className="w-full p-2.5 rounded-lg hover:bg-gray-50 hover:shadow-sm border border-transparent hover:border-gray-200 transition-all cursor-pointer group relative">
                            <p className="text-sm text-gray-700 font-medium truncate pr-6">{chat.title}</p>
                            <p className="text-[10px] text-gray-400 mt-0.5">{chat.date}</p>
                            <button 
                                onClick={(e) => deleteConversation(chat.id, e)}
                                className="absolute right-2 top-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <X className="w-3 h-3" />
                            </button>
                        </div>
                    ))}
                </div>
            ) : null}
          </div>
        )}

        {/* Spacer if closed to push user to bottom */}
        {!sidebarOpen && <div className="flex-1"></div>}

        {/* Bottom Section: User Profile */}
        <div className="p-4 mt-auto border-t border-gray-200">
             {userName === 'Invitado' ? (
                sidebarOpen ? (
                    <div className="flex gap-2">
                        <button 
                            onClick={() => {
                                setAuthMode('login');
                                setIsAuthModalOpen(true);
                            }}
                            className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-all shadow-sm"
                        >
                            Log In
                        </button>
                        <button 
                            onClick={() => {
                                setAuthMode('signup');
                                setIsAuthModalOpen(true);
                            }}
                            className="flex-1 py-2 px-3 bg-transparent border border-gray-200 hover:bg-gray-50 text-gray-700 text-xs font-bold rounded-lg transition-all shadow-sm"
                        >
                            Sign Up
                        </button>
                    </div>
                ) : (
                    <button 
                        onClick={() => {
                            setAuthMode('login');
                            setIsAuthModalOpen(true);
                        }}
                        className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-md mx-auto hover:scale-105 transition-transform"
                        title="Log In / Sign Up"
                    >
                        <User className="w-4 h-4" />
                    </button>
                )
             ) : (
                 <div className={`flex items-center gap-3 ${!sidebarOpen ? 'justify-center' : ''}`}>
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold shadow-md shrink-0">
                        {userName.charAt(0).toUpperCase()}
                    </div>
                    {sidebarOpen && (
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{userName}</p>
                            <button onClick={() => signOut(auth)} className="text-[10px] text-gray-500 hover:text-blue-600 transition-colors flex items-center gap-1">
                                <LogOut size={10} /> Cerrar Sesión
                            </button>
                        </div>
                    )}
                 </div>
             )}
        </div>

        <AuthModal 
          isOpen={isAuthModalOpen} 
          onClose={() => setIsAuthModalOpen(false)} 
          defaultMode={authMode} 
        />

      {sidebarOpen && (
        <div className="px-3 pb-4">
            <div className="h-px bg-gray-200 my-2"></div>

            <button 
              onClick={() => setShowSettings(true)}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 transition-all text-left group"
            >
              <Settings className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span className="text-sm text-gray-700">Configuración</span>
            </button>

            <button 
              onClick={() => {
                  const nextLang = language === 'es' ? 'en' : 'es';
                  setLanguage(nextLang);
              }}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 transition-all text-left group"
            >
              <Globe className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span className="text-sm text-gray-700">Idioma: {language === 'es' ? 'Español' : 'English'}</span>
            </button>

            <button 
              onClick={() => alert('Ayuda: Visita nuestra documentación en línea o contacta soporte.')}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 transition-all text-left group"
            >
              <HelpCircle className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span className="text-sm text-gray-700">Ayuda</span>
            </button>

            <button 
              onClick={() => alert('Mejorar plan: Las opciones premium estarán disponibles pronto.')}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 transition-all text-left group"
            >
              <ArrowUp className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span className="text-sm text-gray-700">Mejorar plan</span>
            </button>

            <button 
              onClick={() => alert('Regalar: ¡Gracias por tu interés! Pronto podrás regalar suscripciones.')}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 transition-all text-left group"
            >
              <Gift className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span className="text-sm text-gray-700">Regalar NEXA OS</span>
            </button>

            <button 
              onClick={() => alert('Descargar: La aplicación de escritorio/móvil está en desarrollo.')}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 transition-all text-left group"
            >
              <Download className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
              <span className="text-sm text-gray-700">Descargar app</span>
            </button>

            <div className="h-px bg-gray-200 my-2"></div>

            <button onClick={handleLogout} className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-red-50 transition-all text-left group">
              <LogOut className="w-4 h-4 text-gray-500 group-hover:text-red-500" />
              <span className="text-sm text-gray-700 group-hover:text-red-600">Cerrar sesión</span>
            </button>
        </div>
      )}
    </div>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Simple Mobile Header */}
        <header className="h-14 flex items-center justify-between px-4 bg-white border-b border-gray-100">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-500">
             <Menu className="w-5 h-5" />
          </button>
          <span className="font-medium text-gray-900">Nexa OS</span>
          <button 
            onClick={() => setShowSettings(true)} 
            className="text-gray-500 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
             <Settings className="w-5 h-5" />
          </button>
        </header>

        {error && (
          <div className="bg-red-900/20 border-b border-red-900/30 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2 flex-1">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <span className="text-sm text-red-300 leading-relaxed">{error}</span>
            </div>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-red-200 ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4 pb-24">
          <div className="max-w-2xl mx-auto space-y-6">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full opacity-40 mt-20">
                 <div className="text-sm">Nexa OS está listo.</div>
              </div>
            )}

            {messages.map((msg, idx) => (
              <div key={idx} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div 
                  className={`max-w-[85%] px-4 py-3 rounded-2xl text-[15px] leading-relaxed shadow-sm ${
                    msg.role === 'user' 
                      ? 'bg-[#2563eb] text-white' 
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  {msg.role === 'assistant' ? (
                      msg.content.split(/(```[\s\S]*?```)/g).map((part, i) => {
                          if (part.startsWith('```')) {
                              const match = part.match(/```(\w+)?\n([\s\S]*?)```/);
                              if (match) {
                                  return <CodeBlock key={i} language={match[1] || ''} code={match[2]} />;
                              }
                          }
                          return <p key={i} className="whitespace-pre-wrap break-words">{part}</p>;
                      })
                  ) : (
                      <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                  )}
                </div>
              </div>
            ))}




            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-nexa-surface/60 backdrop-blur-sm rounded-2xl px-4 py-3 border border-nexa-primary/20 shadow-sm">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
                  </div>
                </div>
              </div>
            )}

            {isListening && (
              <div className="flex justify-center my-4">
                <div className="bg-white border border-red-500/30 rounded-full px-5 py-2 flex items-center gap-3 shadow-sm">
                    <div className="relative flex items-center justify-center">
                        <span className="absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-20 animate-ping"></span>
                        <Mic className="w-4 h-4 text-red-500 relative" />
                    </div>
                    <span className="text-sm text-gray-700 font-medium">Escuchando...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

      <div className="fixed bottom-0 w-full p-3 bg-white border-t border-gray-100 z-20">
        <div className="max-w-2xl mx-auto flex flex-col gap-3">
            {/* Input Container */}
            <div className="w-full flex items-center gap-2 bg-gray-100 rounded-xl px-3 relative">
              <input
                ref={docInputRef}
                type="file"
                multiple
                accept=".txt,.md,.json,.pdf,.doc,.docx,.xls,.xlsx,.csv,.ts,.tsx,.js,.py,.html,.css"
                className="hidden"
                onChange={(e) => {
                  const files = Array.from(e.target.files || []);
                  if (files.length) {
                    setAttachments(prev => [...prev, ...files]);
                    files.forEach(async (f) => {
                       const result = await processFile(f);
                       if (result) {
                          setFileTexts(prev => [...prev, result]);
                       }
                    });
                  }
                }}
              />
              <input
                ref={imageInputRef}
                type="file"
                multiple
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length) setAttachments(prev => [...prev, ...files]);
                }}
              />
              <input
                ref={videoInputRef}
                type="file"
                multiple
                accept="video/*"
                className="hidden"
                onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length) setAttachments(prev => [...prev, ...files]);
                }}
              />
              <input
                ref={audioInputRef}
                type="file"
                multiple
                accept="audio/*"
                className="hidden"
                onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length) setAttachments(prev => [...prev, ...files]);
                }}
              />
              
              {/* @ts-ignore */}
              <input
                  type="file"
                  multiple
                  // @ts-ignore
                  webkitdirectory=""
                  directory=""
                  className="hidden"
                  id="folder-upload"
                  onChange={(e) => {
                      // @ts-ignore
                      const files = Array.from(e.target.files || []);
                      if (files.length) setAttachments(prev => [...prev, ...files]);
                  }}
              />

              {showUploadMenu && (
                <div className="absolute bottom-[calc(100%+8px)] left-0 ml-2 w-60 bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden z-[60] animate-in fade-in slide-in-from-bottom-2">
                    <div className="p-1.5 space-y-0.5">
                        <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">Upload</div>
                        <button onClick={() => { setShowUploadMenu(false); docInputRef.current?.click(); }} className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-xl transition-colors">
                            <div className="p-1.5 bg-blue-100 rounded-lg text-blue-600"><Paperclip className="w-4 h-4" /></div>
                            <span className="font-medium">Document</span>
                        </button>
                        <button onClick={() => { setShowUploadMenu(false); imageInputRef.current?.click(); }} className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-600 rounded-xl transition-colors">
                             <div className="p-1.5 bg-purple-100 rounded-lg text-purple-600"><Image className="w-4 h-4" /></div>
                            <span className="font-medium">Image</span>
                        </button>
                        <button onClick={() => { setShowUploadMenu(false); videoInputRef.current?.click(); }} className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-red-50 hover:text-red-600 rounded-xl transition-colors">
                             <div className="p-1.5 bg-red-100 rounded-lg text-red-600"><Video className="w-4 h-4" /></div>
                            <span className="font-medium">Video</span>
                        </button>
                        <button onClick={() => { setShowUploadMenu(false); audioInputRef.current?.click(); }} className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-amber-50 hover:text-amber-600 rounded-xl transition-colors">
                             <div className="p-1.5 bg-amber-100 rounded-lg text-amber-600"><Music className="w-4 h-4" /></div>
                            <span className="font-medium">Audio</span>
                        </button>
                         <button onClick={() => { setShowUploadMenu(false); document.getElementById('folder-upload')?.click(); }} className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600 rounded-xl transition-colors">
                             <div className="p-1.5 bg-green-100 rounded-lg text-green-600"><FolderPlus className="w-4 h-4" /></div>
                            <span className="font-medium">Folder</span>
                        </button>
                    </div>
                </div>
              )}

              <button
                  onClick={() => setShowUploadMenu(!showUploadMenu)}
                  disabled={isLoading}
                  className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                  <Plus className={`w-5 h-5 transition-transform ${showUploadMenu ? 'rotate-45' : ''}`} />
              </button>

              <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="Escribe a Nexa..."
                  className="flex-1 bg-transparent py-3 outline-none text-gray-900 resize-none overflow-hidden placeholder-gray-400"
                  rows={1}
                  disabled={isLoading}
                  style={{ minHeight: '44px', maxHeight: '120px' }}
              />

              <div className="flex items-center gap-1">
                 {/* Fluid Conversation Mode */}
                 <button
                    onClick={() => {
                        const newState = !autoVoiceMode;
                        setAutoVoiceMode(newState);
                        if (newState) {
                            toggleVoiceRecognition();
                        } else {
                            stopSpeaking();
                            if (isListening) toggleVoiceRecognition();
                        }
                    }}
                    className={`p-2 transition-all rounded-full ${autoVoiceMode ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
                    title="Modo Conversación Fluida"
                 >
                    {autoVoiceMode ? <Headphones className="w-5 h-5 animate-pulse" /> : <Headphones className="w-5 h-5" />}
                 </button>

                 {input.trim() ? (
                   <button
                       onClick={sendMessage}
                       disabled={isLoading}
                       className="p-2 text-[#2563eb] hover:text-blue-600 transition-colors"
                   >
                       <Send className="w-5 h-5" />
                   </button>
                 ) : (
                   <button
                       onClick={toggleVoiceRecognition}
                       className={`p-2 transition-colors ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-400 hover:text-gray-600'}`}
                   >
                       {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                   </button>
                 )}
              </div>



                {attachments.length > 0 && (
                    <div className="absolute bottom-full left-0 w-full px-4 pb-2 flex flex-wrap gap-2 z-10">
                    {attachments.map((f, idx) => (
                        <div key={idx} className="flex items-center gap-2 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-full text-xs text-blue-600 shadow-sm animate-in fade-in zoom-in duration-200">
                        <span className="truncate max-w-[12rem]">{f.name}</span>
                        <button
                            onClick={() => setAttachments(prev => prev.filter((_, i) => i !== idx))}
                            className="text-gray-400 hover:text-red-500 transition-colors"
                        >
                            <X className="w-3 h-3" />
                        </button>
                        </div>
                    ))}
                    </div>
                )}
            </div>

            {/* Quick Actions Menu - Mobile (Horizontal Scroll) */}
            <div className="w-full overflow-x-auto no-scrollbar pb-1 md:hidden">
               <div className="flex items-center gap-2 w-max px-1">
                  {quickActions.map(action => (
                    <button
                      key={action.id}
                      onClick={() => handleQuickAction(action.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border shadow-sm hover:brightness-95 transition-all whitespace-nowrap ${action.color}`}
                    >
                      {action.icon}
                      <span className="text-xs font-medium text-gray-700">{action.label}</span>
                    </button>
                  ))}
               </div>
            </div>

            {/* Quick Actions Menu - Desktop (Minimalist Switch) */}
            <div className="hidden md:flex flex-col w-full">
                <div className="flex justify-center">
                    <button 
                        onClick={() => setMenuExpanded(!menuExpanded)}
                        className="flex items-center gap-2 text-xs text-gray-400 hover:text-blue-500 transition-colors py-1"
                    >
                        {menuExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        <span className="uppercase tracking-widest font-semibold">{menuExpanded ? 'Ocultar Herramientas' : 'Herramientas NEXA'}</span>
                    </button>
                </div>
                
                {menuExpanded && (
                    <div className="grid grid-cols-4 gap-2 pt-2 animate-in slide-in-from-top-2 duration-300">
                        {quickActions.map(action => (
                            <button
                            key={action.id}
                            onClick={() => handleQuickAction(action.id)}
                            className={`flex flex-col items-center gap-2 p-3 rounded-xl border hover:shadow-md transition-all ${action.color} bg-opacity-50 hover:bg-opacity-100`}
                            >
                            {action.icon}
                            <span className="text-xs font-medium text-gray-700 text-center">{action.label}</span>
                            </button>
                        ))}
                    </div>
                )}
            </div>
          </div>
        </div>
      
      {showVideoGen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh] border border-gray-200">
                {/* Header */}
                <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
                    <h3 className="font-bold text-gray-900 flex items-center gap-2">
                        <Video className="w-5 h-5 text-[#2563eb]" />
                        Generador de Video AI
                    </h3>
                    <button onClick={() => setShowVideoGen(false)} className="p-1 hover:bg-gray-100 rounded-full transition-colors">
                        <X className="w-5 h-5 text-gray-500" />
                    </button>
                </div>
                
                <div className="p-6 overflow-y-auto space-y-6">
                    {generatedVideo ? (
                        <div className="flex flex-col items-center justify-center space-y-6">
                             <div className="w-full h-64 md:h-80 bg-black rounded-xl overflow-hidden relative group shadow-2xl ring-1 ring-gray-200 flex items-center justify-center">
                                {videoGenFile && videoGenFile.type.startsWith('image') ? (
                                    <img src={URL.createObjectURL(videoGenFile)} alt="Preview" className="w-full h-full object-cover opacity-60" />
                                ) : (
                                    <div className="flex flex-col items-center justify-center text-white/50">
                                         <Video className="w-16 h-16 mb-2 opacity-50" />
                                         <p className="text-sm font-medium">Vista previa de video</p>
                                    </div>
                                )}
                                <div className="absolute inset-0 flex items-center justify-center z-10">
                                     <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform group-hover:bg-white/30" onClick={() => alert("Reproduciendo video generado...")}>
                                         <Play className="w-10 h-10 text-white ml-1 fill-white" />
                                     </div>
                                </div>
                                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent z-20">
                                     <div className="flex items-center gap-3">
                                        <button className="text-white hover:text-red-400"><Play className="w-4 h-4 fill-white" /></button>
                                        <div className="h-1 bg-white/30 rounded-full overflow-hidden flex-1">
                                            <div className="h-full w-1/3 bg-red-500 rounded-full"></div>
                                        </div>
                                        <span className="text-xs text-white font-mono">00:07 / 00:22</span>
                                        <button className="text-white hover:text-red-400"><Download className="w-4 h-4" /></button>
                                     </div>
                                </div>
                             </div>

                             <div className="text-center space-y-2">
                                <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-900/20 text-green-400 rounded-full text-xs font-bold uppercase tracking-wider border border-green-500/20">
                                    <CheckCircle2 className="w-3 h-3" /> Completado
                                </div>
                                <h3 className="text-2xl font-bold text-gray-900">¡Tu video está listo!</h3>
                                <p className="text-gray-500 max-w-md mx-auto">
                                    Hemos generado una animación basada en tu prompt: <span className="italic text-gray-900">&quot;{videoPrompt}&quot;</span>
                                </p>
                             </div>
                             
                             <div className="flex gap-3 w-full max-w-md">
                                 <button onClick={() => { setShowVideoGen(false); setGeneratedVideo(false); setVideoGenFile(null); setVideoPrompt(''); }} className="flex-1 py-3 text-gray-600 font-medium hover:bg-gray-100 rounded-xl transition-colors border border-gray-200">
                                     Descartar
                                 </button>
                                 <button onClick={() => {
                                     setShowVideoGen(false);
                                     setGeneratedVideo(false);
                                     setMessages(prev => [...prev, {
                                        role: 'assistant',
                                        content: `🎥 **Video Generado**\n\nAquí tienes el resultado de tu solicitud: "${videoPrompt}"\n\n*[Video adjunto: generation_v2_480p.mp4]*`
                                     }]);
                                     setVideoGenFile(null);
                                     setVideoPrompt('');
                                 }} className="flex-1 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/30 hover:shadow-blue-500/40 transition-all transform hover:-translate-y-0.5">
                                     Insertar en Chat
                                 </button>
                             </div>
                        </div>
                    ) : (
                        <>
                            <div className="space-y-2">
                               <label className="text-sm font-medium text-gray-500">1. Sube tu imagen o video de referencia</label>
                                <div 
                                    className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center transition-all ${videoGenFile ? 'border-red-500/50 bg-red-50' : 'border-gray-300 hover:border-red-400 hover:bg-gray-50'}`}
                                    onDragOver={(e) => e.preventDefault()}
                                    onDrop={(e) => {
                                        e.preventDefault();
                                        const file = e.dataTransfer.files[0];
                                        if(file) setVideoGenFile(file);
                                    }}
                                >
                                    {videoGenFile ? (
                                        <div className="text-center relative">
                                            {videoGenFile.type.startsWith('image') ? (
                                                <img src={URL.createObjectURL(videoGenFile)} alt="File preview" className="h-32 rounded-lg shadow-sm mb-2 object-cover" />
                                            ) : (
                                                <div className="h-32 w-32 bg-gray-100 rounded-lg flex items-center justify-center mb-2 mx-auto">
                                                    <Video className="w-10 h-10 text-gray-400" />
                                                </div>
                                            )}
                                            <p className="text-sm font-medium text-gray-900">{videoGenFile.name}</p>
                                            <button onClick={() => setVideoGenFile(null)} className="text-xs text-red-400 hover:underline mt-1">Cambiar archivo</button>
                                        </div>
                                    ) : (
                                        <div className="text-center cursor-pointer" onClick={() => document.getElementById('video-upload')?.click()}>
                                            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3 text-red-400">
                                                <Plus className="w-6 h-6" />
                                            </div>
                                            <p className="text-sm text-gray-900 font-medium">Haz clic o arrastra un archivo aquí</p>
                                            <p className="text-xs text-gray-500 mt-1">Soporta JPG, PNG, MP4</p>
                                        </div>
                                    )}
                                    <input type="file" id="video-upload" className="hidden" accept="image/*,video/*" onChange={(e) => e.target.files?.[0] && setVideoGenFile(e.target.files[0])} />
                                </div>
                            </div>

                            {/* Prompt Section */}
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-gray-500">2. Describe cómo quieres recrearlo</label>
                                <textarea 
                                    value={videoPrompt}
                                    onChange={(e) => setVideoPrompt(e.target.value)}
                                    placeholder="Ej: Haz que el paisaje se mueva suavemente, añade lluvia y una atmósfera melancólica..."
                                    className="w-full p-3 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 placeholder-gray-400 focus:border-red-400 focus:ring-2 focus:ring-red-900/20 outline-none resize-none h-24 text-sm"
                                />
                            </div>

                            {/* Settings */}
                            <div className="flex items-center gap-4 text-sm text-gray-500 bg-gray-50 p-3 rounded-lg border border-gray-200">
                                <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4 text-gray-400" />
                                    <span>Duración: <strong className="text-gray-900">22 segundos</strong></span>
                                </div>
                                <div className="h-4 w-px bg-gray-200"></div>
                                <div className="flex items-center gap-2">
                                    <Sparkles className="w-4 h-4 text-gray-400" />
                                    <span>Modelo: <strong className="text-gray-900">NEXA Video Gen 2.0</strong></span>
                                </div>
                            </div>

                            {/* Generate Button */}
                            <button 
                                onClick={handleGenerateVideo}
                                disabled={!videoGenFile || !videoPrompt || isGeneratingVideo}
                                className={`w-full py-3 rounded-xl font-medium text-white shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center gap-2 ${
                                    !videoGenFile || !videoPrompt || isGeneratingVideo
                                    ? 'bg-gray-200 cursor-not-allowed text-gray-400' 
                                    : 'bg-[#2563eb] hover:bg-blue-600 hover:scale-[1.02] active:scale-[0.98]'
                                }`}
                            >
                                {isGeneratingVideo ? (
                                    <>
                                        <Loader2 className="w-5 h-5 animate-spin" />
                                        Generando Video (Esto tomará unos segundos)...
                                    </>
                                ) : (
                                    <>
                                        <Zap className="w-5 h-5" />
                                        Generar Video
                                    </>
                                )}
                            </button>
                        </>
                    )}
                </div>
            </div>
        </div>
      )}
       {showCreative && (
           <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto border border-gray-200">
                <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                    <Gift className="w-6 h-6 text-purple-600" />
                    Estudio Creativo NEXA
                  </h2>
                  <button onClick={() => setShowCreative(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <X className="w-6 h-6 text-gray-500" />
                  </button>
                </div>
 
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                   {/* Web Generator */}
                   <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-2xl border border-blue-100 hover:shadow-lg hover:shadow-blue-500/10 transition-all cursor-pointer group"
                        onClick={() => {
                            setCodeMode(true);
                            setMode('fast');
                            setInput("Crea una página web moderna y responsiva para [TU TEMA AQUÍ] que incluya una sección de héroe, características y contacto. Usa Tailwind CSS.");
                            setShowCreative(false);
                        }}>
                       <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                           <Globe className="w-6 h-6 text-blue-600" />
                       </div>
                       <h3 className="text-lg font-semibold text-gray-900 mb-2">Diseñador Web</h3>
                       <p className="text-sm text-gray-600">Crea sitios web completos, landing pages y componentes UI al instante.</p>
                   </div>
 
                   {/* Logo Creator */}
                   <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-2xl border border-purple-100 hover:shadow-lg hover:shadow-purple-500/10 transition-all cursor-pointer group"
                        onClick={() => {
                            setCodeMode(true);
                            setMode('fast');
                            setInput("Genera el código SVG para un logo moderno y minimalista de [NOMBRE/EMPRESA]. El logo debe representar [CONCEPTO]. Usa colores vibrantes.");
                            setShowCreative(false);
                        }}>
                       <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                           <Code className="w-6 h-6 text-purple-600" />
                       </div>
                       <h3 className="text-lg font-semibold text-gray-900 mb-2">Creador de Logos</h3>
                       <p className="text-sm text-gray-600">Diseña logotipos vectoriales (SVG) listos para usar en tus proyectos.</p>
                   </div>
 
                   {/* Book Writer */}
                   <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-2xl border border-amber-100 hover:shadow-lg hover:shadow-amber-500/10 transition-all cursor-pointer group"
                        onClick={() => {
                            setCodeMode(false);
                            setMode('deep');
                            setInput("Escribe el primer capítulo de un libro sobre [TEMA]. El tono debe ser [TONO]. Incluye diálogos y descripciones detalladas.");
                            setShowCreative(false);
                        }}>
                       <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                           <FolderPlus className="w-6 h-6 text-amber-600" />
                       </div>
                       <h3 className="text-lg font-semibold text-gray-900 mb-2">Escritor de Libros</h3>
                       <p className="text-sm text-gray-600">Ayuda para escribir novelas, cuentos o documentación técnica extensa.</p>
                   </div>
 
                   {/* Video Script */}
                   <div className="bg-gradient-to-br from-red-50 to-rose-50 p-6 rounded-2xl border border-red-100 hover:shadow-lg hover:shadow-red-500/10 transition-all cursor-pointer group"
                        onClick={() => {
                            setCodeMode(false);
                            setMode('fast');
                            setInput("Crea un guion detallado para un video de YouTube sobre [TEMA]. Incluye escenas, narración y sugerencias visuales.");
                            setShowCreative(false);
                        }}>
                       <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                           <Volume2 className="w-6 h-6 text-red-600" />
                       </div>
                       <h3 className="text-lg font-semibold text-gray-900 mb-2">Guionista de Video</h3>
                       <p className="text-sm text-gray-600">Genera guiones, ideas y estructuras para contenido audiovisual.</p>
                   </div>
                </div>
              </div>
           </div>
         )}
       {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all scale-100 border border-gray-200">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gray-50">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Settings className="w-5 h-5 text-blue-600" />
                Configuración
              </h3>
              <button 
                onClick={() => setShowSettings(false)} 
                className="text-gray-500 hover:text-gray-900 p-1 hover:bg-gray-200 rounded-full transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
             
             <div className="p-6 space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-900">Tu Nombre</label>
                <input 
                  type="text" 
                  value={userName} 
                  onChange={(e) => setUserName(e.target.value)}
                  onBlur={(e) => saveUserName(e.target.value)}
                  placeholder="¿Cómo te llamas?"
                  className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all text-gray-900 placeholder-gray-400"
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                <span className="text-sm font-medium text-gray-900">Estado de Red</span>
                <span className={`text-xs px-2 py-1 rounded-full ${isOnline ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-red-100 text-red-700 border border-red-200'}`}>
                  {isOnline ? 'En línea' : 'Sin conexión'}
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${voiceEnabled ? 'bg-blue-100 text-blue-600' : 'bg-gray-200 text-gray-500'}`}>
                    {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Respuesta por voz</p>
                    <p className="text-xs text-gray-500">NEXA leerá las respuestas en voz alta</p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    stopSpeaking();
                    setVoiceEnabled(!voiceEnabled);
                  }}
                  className={`w-12 h-6 rounded-full transition-colors relative ${voiceEnabled ? 'bg-blue-600' : 'bg-gray-300'}`}
                >
                  <div 
                    className={`w-5 h-5 bg-white rounded-full shadow-sm absolute top-0.5 transition-all duration-300 ${voiceEnabled ? 'translate-x-6' : 'translate-x-0.5'}`}
                  ></div>
                </button>
              </div>

               <div className="space-y-2">
                 <label className="text-sm font-medium text-gray-900">Idioma</label>
                 <select 
                   value={language}
                   onChange={(e) => setLanguage(e.target.value as 'es'|'en'|'zh')}
                   className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all text-gray-900"
                 >
                   <option value="es" className="bg-white">Español (España)</option>
                   <option value="en" className="bg-white">English (US)</option>
                   <option value="zh" className="bg-white">中文 (简体)</option>
                 </select>
                </div>
                


                {/* Backup & Repair System */}
               <div className="space-y-2">
                <label className="text-sm font-medium text-gray-900 flex items-center gap-2">
                  <HardDrive className="w-4 h-4" /> Copia de Seguridad y Reparación
                </label>
                <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 space-y-3">
                  <div className="flex items-center justify-between">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                           <Shield className="w-5 h-5" />
                        </div>
                        <div>
                           <p className="font-medium text-gray-900">Backup Automático</p>
                           <p className="text-xs text-gray-500">Guarda proyecto y datos en /backups</p>
                        </div>
                     </div>
                     <button 
                       onClick={handleSystemBackup}
                       disabled={isBackingUp}
                       className="px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
                     >
                       {isBackingUp ? 'Guardando...' : 'Backup Ahora'}
                     </button>
                  </div>
                  <div className="h-px bg-gray-200"></div>
                  <div className="flex items-center justify-between">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-pink-100 text-pink-600 rounded-lg">
                           <RotateCcw className="w-5 h-5" />
                        </div>
                        <div>
                           <p className="font-medium text-gray-900">Restauración</p>
                           <p className="text-xs text-gray-500">Recuperar último estado seguro</p>
                        </div>
                     </div>
                     <button 
                       onClick={handleSystemRestore}
                       className="px-3 py-1.5 bg-white border border-pink-200 text-pink-600 text-xs font-medium rounded-lg hover:bg-pink-50 transition-colors"
                     >
                       Restaurar
                     </button>
                  </div>
                </div>
              </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-900">Exportar conversación</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const text = messages.map(m => `${m.role}: ${m.content}`).join('\n\n');
                        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url; a.download = 'conversacion.txt'; a.click();
                        URL.revokeObjectURL(url);
                      }}
                      className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-blue-600 hover:bg-blue-50 transition-all text-sm"
                    >
                      Descargar .TXT
                    </button>
                    <button
                      onClick={() => {
                        const blob = new Blob([JSON.stringify(messages, null, 2)], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url; a.download = 'conversacion.json'; a.click();
                        URL.revokeObjectURL(url);
                      }}
                      className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-blue-600 hover:bg-blue-50 transition-all text-sm"
                    >
                      Descargar .JSON
                    </button>
                    <button
                      onClick={() => {
                        const w = window.open('', '_blank');
                        if (!w) return;
                        const html = `
                          <html><head><title>Conversación</title>
                          <style>
                            body{font-family:system-ui,Segoe UI,Arial;padding:24px;}
                            .msg{margin-bottom:16px;padding:12px;border-radius:12px;}
                            .user{background:#e0f2fe;}
                            .assistant{background:#f8fafc;}
                            .system{background:#ecfeff;}
                            h1{font-size:18px;margin-bottom:12px;}
                          </style></head><body>
                          <h1>Conversación NEXA OS</h1>
                          ${messages.map(m => `<div class="msg ${m.role}"><strong>${m.role}</strong><div>${m.content.replace(/</g,'&lt;')}</div></div>`).join('')}
                          </body></html>`;
                        w.document.write(html);
                        w.document.close();
                        w.focus();
                        w.print();
                      }}
                      className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-blue-600 hover:bg-blue-50 transition-all text-sm"
                    >
                      Guardar como PDF
                    </button>
                    <button
                      onClick={async () => {
                        const zip = new JSZip();
                        const text = messages.map(m => `${m.role}: ${m.content}`).join('\n\n');
                        zip.file('conversacion.txt', text);
                        zip.file('conversacion.json', JSON.stringify(messages, null, 2));
                        if (attachments.length) {
                          const folder = zip.folder('adjuntos');
                          if (folder) {
                            for (const f of attachments) {
                              const arrayBuffer = await f.arrayBuffer();
                              folder.file(f.name, arrayBuffer);
                            }
                          }
                        }
                        const blob = await zip.generateAsync({ type: 'blob' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url; a.download = 'nexa_conversacion.zip'; a.click();
                        URL.revokeObjectURL(url);
                      }}
                      className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-blue-600 hover:bg-blue-50 transition-all text-sm"
                    >
                      Descargar .ZIP
                    </button>
                  </div>
                </div>
 
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-900">Plantillas rápidas de código</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        setCodeMode(true);
                        setInput("Crea un componente React funcional con:\n- botón \"Incrementar\"\n- contador en estado\n- estilos básicos Tailwind\nIncluye TypeScript.");
                        setShowSettings(false);
                      }}
                      className="px-3 py-2 bg-pink-50 border border-pink-200 rounded-lg text-pink-600 hover:bg-pink-100 transition-all text-sm"
                    >
                      React: Contador
                    </button>
                    <button
                      onClick={() => {
                        setCodeMode(true);
                        setInput("Crea una ruta API de Next.js (app/api/example/route.ts) que acepte POST con JSON {name} y responda {greeting: \"Hola {name}\"} con validación y tipos TypeScript.");
                        setShowSettings(false);
                      }}
                      className="px-3 py-2 bg-pink-50 border border-pink-200 rounded-lg text-pink-600 hover:bg-pink-100 transition-all text-sm"
                    >
                      Next.js: API
                    </button>
                    <button
                      onClick={() => {
                        setCodeMode(true);
                        setInput("Escribe una función TypeScript utilitaria:\n- nombre: formatCurrency\n- parámetros: amount:number, currency?:string=\"EUR\", locale?:string=\"es-ES\"\n- retorna string con Intl.NumberFormat\n- añade pruebas básicas de uso.");
                        setShowSettings(false);
                      }}
                      className="px-3 py-2 bg-pink-50 border border-pink-200 rounded-lg text-pink-600 hover:bg-pink-100 transition-all text-sm"
                    >
                      TS: Utilidad
                    </button>
                    <button
                      onClick={() => {
                        setCodeMode(true);
                        setInput("Genera un README breve para un proyecto Next.js con:\n- requisitos\n- instalación\n- scripts\n- despliegue en Vercel\n- estructura de carpetas.");
                        setShowSettings(false);
                      }}
                      className="px-3 py-2 bg-nexa-secondary/10 border border-nexa-secondary/20 rounded-lg text-nexa-secondary hover:bg-nexa-secondary/20 transition-all text-sm"
                    >
                      README rápido
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 border-t border-nexa-primary/20 bg-nexa-dark/50 flex justify-end">
                <button 
                  onClick={() => setShowSettings(false)}
                  className="px-6 py-2 bg-gradient-to-r from-nexa-primary to-cyan-600 hover:from-cyan-400 hover:to-nexa-primary text-black rounded-lg font-medium transition-all shadow-lg shadow-nexa-primary/20"
                >
                  Listo
                </button>
              </div>
            </div>
          </div>
       )}
    </div>
    </div>
  );
}
