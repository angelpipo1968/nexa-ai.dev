package com.nexaos.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
